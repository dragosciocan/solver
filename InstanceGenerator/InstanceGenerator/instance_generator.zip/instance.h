//
//  instance.h
//  InstanceGenerator
//
//  Created by Dragos Ciocan on 2/5/13.
//  Copyright (c) 2013 Dragos Ciocan. All rights reserved.
//

#ifndef InstanceGenerator_instance_h
#define InstanceGenerator_instance_h

#include <ext/hash_map>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

namespace distributed_solver {
class Instance {
    int num_advertisers_;
    int num_impressions_;
    int num_slots_; // Number of ad slots per impression.
    double bid_sparsity_; // Percentage of impressions advertiser bids for.
    std::vector<__gnu_cxx::hash_map<int, double>> bids_matrix_; // Matrix of bids of advertisers for impressions.
    
    
public:
    Instance(int num_advertisers, int num_impressions, int num_slots, double bid_sparsity);
    void GenerateInstance();
    void WriteInstanceToCSV(std::string file_name_handle);
};
}

#endif
