//
//  instance.cpp
//  InstanceGenerator
//
//  Created by Dragos Ciocan on 2/5/13.
//  Copyright (c) 2013 Dragos Ciocan. All rights reserved.
//


#include "instance.h"
#include <iostream>

namespace distributed_solver {
    Instance::Instance(int num_advertisers, int num_impressions, int num_slots, double bid_sparsity) {
        num_advertisers_ = num_advertisers;
        num_impressions_ = num_impressions;
        num_slots_ = num_slots;
        bid_sparsity_ = bid_sparsity;
    }
    
    void Instance::GenerateInstance() {
        srand(1);
        for (int j = 0; j < num_advertisers_; ++j) {
            // Generate bids for advertiser j.
            __gnu_cxx::hash_map<int, double> bid_row;
            for (int i = 0; i < (bid_sparsity_ * num_impressions_); ++i) {
                int index = random() % num_impressions_;
                double bid = (double) (random() + 1) / ((double) RAND_MAX);
                bid_row[index] = bid;
            }
            bids_matrix_.push_back(bid_row);
        }
    }
    
    void Instance::WriteInstanceToCSV(std::string file_name_handle) {
        // Open file.
        std::string file_name;
        file_name = file_name_handle + std::to_string(num_advertisers_) + "x" + std::to_string(num_impressions_) + "x" + std::to_string(num_slots_) + "x" + std::to_string(bid_sparsity_) + ".csv";
        __gnu_cxx::ofstream file;
        std::cout << "Writing instance " + file_name + "\n";
        file.open(file_name);
        // Go through bids and write them to file.
        std::string bid_row;
        for (int j = 0; j < num_advertisers_; ++j) {
            // Get bid vector for each advertiser, and write it to a row of the csv.
            for (__gnu_cxx::hash_map<int, double>::iterator iter = bids_matrix_[j].begin(); iter != bids_matrix_[j].end(); ++iter) {
                bid_row = bid_row + std::to_string(iter->first) + "," + std::to_string(iter->second) + ",";
            }
            bid_row = bid_row + "\n";
            file << bid_row;
            bid_row = "";
        }
        
        // Close file
        file.close();
    }
}
